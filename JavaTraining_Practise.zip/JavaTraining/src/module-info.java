/**
 * 
 */
/**
 * @author 2143081
 *
 */
module JavaTraining {
}