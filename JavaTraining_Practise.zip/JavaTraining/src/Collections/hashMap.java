/*package Collections;

import java.util.HashMap;
import java.util.Iterator;

import java.util.Set;


public class hashMap {
// create a hastable pass table set collections 
	public static void main(String[] args) {
		// It will take in key value pair
     HashMap<Integer,String> hm=new HashMap<Integer,String>();
     hm.put(1,"hello");
     hm.put(2,"goodbye");
     hm.put(3,"evenig");
     hm.put(5,"morning");
    System.out.println( hm.get(2));
    Set sn=hm.entrySet();
    Iterator it=sn.iterator();
    while(it.hasNext())
    {    
    	 Map.Entry mp = (Map.Entry)it.next();
    	//System.out.println(mp.getKey());
    //System.out.println(mp.getvalue());
    }
     
	}

}*/
