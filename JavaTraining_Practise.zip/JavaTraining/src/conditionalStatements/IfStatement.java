package conditionalStatements;

public class IfStatement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		if(a>0&&a<100) {
			System.out.println("True"); 
		}

	}

}
