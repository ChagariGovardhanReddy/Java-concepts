package conditionalStatements;

public class Terinaryoperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int d=9,f=7,h=8,temp;
	     temp=(d<f)?f:d;
	    int x= (temp>h)?temp:h;
		System.out.println(x);
		
      
      
	}

}
