package conditionalStatements;

public class NestedIf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int cl=5,rank=10;
		if(cl==5) {
			if(rank>5) {
				System.out.println("Goldmedalist");
			}
				
		}

	}

}
