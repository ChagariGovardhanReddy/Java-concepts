package conditionalStatements;

public class IfElseLadder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=9;
		if(a>0) {
			System.out.println("Positive number");
		}
		else if(a<0){
			
			System.out.println("Negative number");
		}
		else {
			System.out.println("zero"); 
		}
	}

}
