package oopsClass;

public class ClassEgKiMainMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     ClassEg dg=new ClassEg();
     dg.gorreganga="86875";
     dg.gova="7868";
     dg.money=9;
     dg.display();
	}

}
