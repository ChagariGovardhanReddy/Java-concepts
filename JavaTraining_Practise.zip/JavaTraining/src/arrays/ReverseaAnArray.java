package arrays;

public class ReverseaAnArray {

	public static void main(String[] args) {
		int a[]= {19,23,4,56,5};
		//for(int i=a.length-1;i>=0;i--) {
		//	System.out.println(a[i]);
		//}
		int i=4;
		while(i>=0) {
			System.out.println(a[i]);
			i--;
		}

	}

}

