package Strings;

public class StringConcatinate {

	public static void main(String[] args) {
		String s1="god";
		String s2="govardhan";
		System.out.println(s1+" "+s2);
		String s3=s1.concat(s2);
        System.out.println(s3);
	}

}
