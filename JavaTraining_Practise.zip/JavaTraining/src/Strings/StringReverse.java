package Strings;

public class StringReverse {

	public static void main(String[] args) {
	/*	String s="govardhan";
		String s1="";
		for(int i=s.length()-1;i>=0;i--) {
			s1=s1+s.charAt(i);
		}
		System.out.println(s1);*/
	//method
		/*StringBuffer  s=new StringBuffer("hdhj");
		StringBuffer s2=s.reverse();
		System.out.println(s2);*/
	//method
		StringBuilder  s=new StringBuilder("Gova");
		StringBuilder s2=s.reverse();
		System.out.println(s2);
		
		

	}

}
