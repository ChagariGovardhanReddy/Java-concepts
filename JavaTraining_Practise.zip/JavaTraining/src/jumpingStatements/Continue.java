package jumpingStatements;

public class Continue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//      for(int i=0;i<=10;i++) {
//    	  if(i==5) {
//    		  continue;
//    	  }
//    	  System.out.println(i);
//      }
//      for(int j=0;j<=10;j++) {
//    	  if(j==5 || j==3) {
//    		  continue;
//    	  }
//    	  System.out.println(j);
    	  for(int k=21;k<30;k++) {
    		  if(k%2==0) {
    			  System.out.println(k);
    		  }
    		  //else {
    			//  System.out.println(k);
    		  //}
    	  }
      }
	}



