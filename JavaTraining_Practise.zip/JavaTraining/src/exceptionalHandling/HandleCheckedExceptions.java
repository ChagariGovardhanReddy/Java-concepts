/*package exceptionalHandling;

import java.io.FileNotFoundException;

public class HandleCheckedExceptions {

	public static void main(String[] args) {
		// using Try...Catch
		//throws
		try {
		//	FileInputStream file=new FileInputStream("C:\\file.txt");
			
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}*/
