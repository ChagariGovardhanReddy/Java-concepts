package loopingStatements;

public class Whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s=0;
		while(s<=8) {
			System.out.println(" ganga");
			s++;
		}

	}

}
