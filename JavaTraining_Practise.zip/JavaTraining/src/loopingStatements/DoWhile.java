package loopingStatements;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int d=1;
       do{
    	   System.out.println("hello World");
    	   d++;
       }while(d<=5);
	}

}
