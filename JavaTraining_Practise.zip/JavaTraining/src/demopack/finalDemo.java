package demopack;

public class finalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//you can make methods also final 
		//
      final int i=4;
      
	}

}

